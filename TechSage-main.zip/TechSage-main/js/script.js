function subscribeAlert() {
  alert("Thanks for subscribing to TechSage Journal!");
}
